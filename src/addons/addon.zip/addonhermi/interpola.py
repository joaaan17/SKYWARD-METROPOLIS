import mathutils

"""
interpola.py

Algoritmos de interpolación

Autores: Grupo 5.


"""

def lineal(t: float,t0: float,t1: float ,x0: float ,x1: float):
    
    pos = x0 + (t - t0)/(t1 - t0)*(x1 - x0)
    
    return pos

def catmull_rom(t: float, t0: float, t1: float, t2: float, t3: float, 
                p0: float, p1: float, p2: float, p3: float, tension: float):

    # Normalización de u
    u = (t - t1) / (t2 - t1)
    
    # Vector de potencias de u
    U = mathutils.Vector([u**3, u**2, u, 1])
    
    # Matriz modificada de Catmull-Rom
    M = mathutils.Matrix([
        [-tension, 2 - tension, tension - 2, tension],
        [2 * tension, tension - 3, 3 - 2 * tension, -tension],
        [-tension, 0, tension, 0],
        [0, 1, 0, 0]
    ])
    
    # Vector de posiciones
    B = mathutils.Vector([p0, p1, p2, p3])
    
    # Producto escalar y matricial para el cálculo del polinomio de Catmull-Rom
    C = U @ M @ B
    
    return C


def hermite(t, t0, t1, x0, x1, v0, v1):
    """Interpolación Hermite"""
    t_norm = (t - t0) / (t1 - t0)
    
    h00 = 2 * t_norm*3 - 3 * t_norm*2 + 1
    h01 = -2 * t_norm*3 + 3 * t_norm*2
    h10 = t_norm*3 - 2 * t_norm*2 + t_norm
    h11 = t_norm*3 - t_norm*2

    pos = (h00 * x0 + h01 * x1 + h10 * v0 + h11 * v1)
    
    return pos 


