
import bpy
import math
import sys
import os

# Añadir la ruta donde se encuentran tus módulos
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import interpola

# Propiedad para la tensión, sin límite superior
bpy.types.WindowManager.tension = bpy.props.FloatProperty(
    name="Tension",
    description="Tensión para Catmull-Rom",
    default=0.5,
    min=0.0  # Sin límite superior
)

bpy.types.WindowManager.velocidad1 = bpy.props.FloatProperty(
    name="Velocidad1",
    description="Velocidad 1",
    default=0.5,

)

bpy.types.WindowManager.velocidad2 = bpy.props.FloatProperty(
    name="Velocidad2",
    description="Velocidad 2",
    default=0.5,
)

# Ejercicio 2
def get_posicion_x_loop(frame):
    t = frame / 24.0  
    return 5 * math.cos(t)  # Radio de 5, centrado en el origen

def get_posicion_y_loop(frame):
    t = frame / 24.0
    return 5 * math.sin(t)  # Radio de 5, centrado en el origen

# Ejercicio 1
def get_posicion1(frm: float):
    t = frm / 24.0
    if t <= 0:
        posx = 0.0
    elif t <= 5.0:
        posx = 10.0 * t / 5.0
    else:
        posx = 10.0
    print(f"Frame: {frm}, Posición X: {posx}")
    return posx

# Ejercicio 3
def get_posicion2(frm, obj, coord):
    """Obtiene la posición interpolada según el frame y la interpolación seleccionada"""
    
    # Obtiene la curva de animación
    c = obj.animation_data.action.fcurves.find('location', index=coord)

    prev_kf = None
    next_kf = None

    # Encontrar los dos keyframes entre los que se encuentra el frame actual
    for i in range(len(c.keyframe_points) - 1):
        kf1 = c.keyframe_points[i]
        kf2 = c.keyframe_points[i + 1]

        if kf1.co[0] <= frm <= kf2.co[0]:
            anterior_kf = c.keyframe_points[i - 1] if i > 0 else None
            prev_kf = kf1
            next_kf = kf2
            posterior_kf = c.keyframe_points[i + 2] if i + 2 < len(c.keyframe_points) else None
            break

    # Manejo de casos fuera de los keyframes
    if prev_kf is None or next_kf is None:
        print("El frame está fuera de los keyframes")
        
        return 0.0  

    # Dependiendo del método de interpolación seleccionado, se elige el algoritmo
    selected_interpolation = bpy.context.window_manager.selected_shape

    if selected_interpolation == 'LINEAL':
        pos = interpola.lineal(frm, prev_kf.co[0], next_kf.co[0], prev_kf.co[1], next_kf.co[1])

    elif selected_interpolation == 'CATMULL-ROM':
        tension = bpy.context.window_manager.tension  # Obtener la tensión desde el panel
        
        if  len(c.keyframe_points) >= 2:

                # Estos pueden ser keyframes anteriores y siguientes a los actuales
                p0 = anterior_kf.co[1] if anterior_kf is not None else prev_kf.co[1]  # Reflejar el valor de p1 si no hay anterior_kf
                p1 = prev_kf.co[1]  # Punto actual
                p2 = next_kf.co[1]  # Punto siguiente
                p3 = posterior_kf.co[1] if posterior_kf is not None else next_kf.co[1]  # Reflejar el valor de p2 si no hay posterior_kf

                # Lo mismo con los tiempos
                t0 = anterior_kf.co[0] if anterior_kf is not None else prev_kf.co[0]  # Reflejar t1 si no hay anterior_kf
                t1 = prev_kf.co[0]  # Tiempo actual
                t2 = next_kf.co[0]  # Tiempo siguiente
                t3 = posterior_kf.co[0] if posterior_kf is not None else next_kf.co[0]  # Reflejar t2 si no hay posterior_kf
                
                # Realizar la interpolación
                pos = interpola.catmull_rom(frm, t0, t1, t2, t3, p0, p1, p2, p3, tension)


    elif selected_interpolation == 'HERMITE':
        v0 = bpy.context.window_manager.velocidad1
        v1 = bpy.context.window_manager.velocidad2
        pos = interpola.hermite(frm, prev_kf.co[0], next_kf.co[0], prev_kf.co[1], next_kf.co[1], v0, v1)


    return pos  

# Ejercicio 4
def asigna_driver_posicion(obj):
    for coord in range(3):
        print("coordenada:", coord)
        drv = obj.driver_add('location', coord).driver
        drv.use_self = True
        drv.expression = f"get_pos2(frame,self,{coord})"

# Panel personalizado
class OBJECT_PT_CustomPanel(bpy.types.Panel):
    bl_label = "Drivers Control"
    bl_idname = "OBJECT_PT_custom_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Drivers Control"

    def draw(self, context):
        layout = self.layout

        layout.label(text="Generación trayectoria interpolada")
        layout.prop(context.window_manager, "selected_shape", text="Elige una forma")

        if context.window_manager.selected_shape == 'CATMULL-ROM':
            # Mostrar propiedad de tensión solo si se selecciona Catmull-Rom
            layout.prop(context.window_manager, "tension", text="Tensión Catmull-Rom")

        if context.window_manager.selected_shape == 'HERMITE':
            # Mostrar propiedad de tensión solo si se selecciona Catmull-Rom
            layout.prop(context.window_manager, "velocidad1", text="Velocidad Hermite 1")
            layout.prop(context.window_manager, "velocidad2", text="Velocidad Hermite 2")

        layout.operator("object.create_trayectoria", text="Crear trayectoria")

enum_items = [
    ('LINEAL', "Interpolacion lineal", "Interpola linealmente"),
    ('CATMULL-ROM', "Interpolacion Catmull-Rom", "Interpola usando Catmull-Rom"),
    ('HERMITE', "Interpolacion Hermite", "Interpola usando Hermite")
]

class OBJECT_OT_CreateTrayectoria(bpy.types.Operator):
    bl_idname = "object.create_trayectoria"
    bl_label = "Crear Trayectoria"

    shape = bpy.props.EnumProperty(
        name="Tipo de interpolación",
        description="Selecciona la interpolación",
        items=enum_items,
        default='LINEAL'
    )
    
    def invoke(self, context, event):
        asigna_driver_posicion(context.object)
        bpy.ops.object.paths_update_visible()
        self.report({'INFO'}, "Trayectoria creada exitosamente")
        return {'FINISHED'}

def register():
    bpy.app.driver_namespace['get_pos2'] = get_posicion2
    bpy.app.driver_namespace['get_pos1'] = get_posicion1
    bpy.app.driver_namespace['get_posicion_x_loop'] = get_posicion_x_loop
    bpy.app.driver_namespace['get_posicion_y_loop'] = get_posicion_y_loop

    bpy.utils.register_class(OBJECT_PT_CustomPanel)
    bpy.utils.register_class(OBJECT_OT_CreateTrayectoria)

    if hasattr(bpy.types.WindowManager, "selected_shape"):
        del bpy.types.WindowManager.selected_shape

    bpy.types.WindowManager.selected_shape = bpy.props.EnumProperty(
        name="Tipo de interpolación",
        description="Selecciona la interpolación",
        items=enum_items,
        default='LINEAL'
    )
    print("Definimos Drivers")

def unregister():
    bpy.utils.unregister_class(OBJECT_PT_CustomPanel)
    bpy.utils.unregister_class(OBJECT_OT_CreateTrayectoria)
    del bpy.types.WindowManager.selected_shape
    if hasattr(bpy.types.WindowManager, "tension"):
        del bpy.types.WindowManager.tension

if __name__ == "__main__":
    register()

    obj_activo = bpy.context.view_layer.objects.active 

    if obj_activo:
        asigna_driver_posicion(obj_activo)
        print("drivers asignados")
    else:
        print("No hay obj activo / driver no asignado")
